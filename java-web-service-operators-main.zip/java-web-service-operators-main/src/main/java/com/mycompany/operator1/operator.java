/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.operator1;

/**
 *
 * @author kokye
 */
public class operator {

    /**
     * @param args the command line arguments
     */
    public int sum(int a, int b)
    {
        return a+b;
    }
    public int multiply(int a, int b)
    {
        return a*b;
    }
    public int sub(int a, int b)
    {
        return a-b;
    }
    public int divide(int a, int b)
    {
        return a/b;
    }
    public static void main(String args[]) {
        // TODO code application logic here
    }
}
